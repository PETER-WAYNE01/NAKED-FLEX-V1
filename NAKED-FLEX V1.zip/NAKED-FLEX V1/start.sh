#!/bin/bash

# Start the HTTP server in the background
node server.js &

# Start the bot
npm start